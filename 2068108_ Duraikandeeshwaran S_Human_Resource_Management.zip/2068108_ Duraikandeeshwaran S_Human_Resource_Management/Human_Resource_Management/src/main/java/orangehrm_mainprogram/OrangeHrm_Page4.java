package orangehrm_mainprogram;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class OrangeHrm_Page4 {

	WebDriver wd;
	Properties p;
	FileReader fr;
	WebElement job;
	WebElement jobTitle;
	List<String> titles = new ArrayList<String>();

	public List<String> getTitles() {
		return titles;
	}

	public void setDriver(WebDriver wd) {
		this.wd = wd;
	}

	public void setProperty(Properties p) {
		this.p = p;
	}
/*******************************************************************************************
 * Method Name : public void validating_job()                                              *
 * Method Description : To click on job & validate whether jobtitle is present or not      *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 2068108                                                                   *
 *******************************************************************************************/
	public void validating_job() {
		job = wd.findElement(By.xpath("//a[@id='menu_admin_Job']"));
		job.click();
		jobTitle = wd.findElement(By.id("menu_admin_viewJobTitleList"));
		if (jobTitle.isDisplayed()) {
			System.out.println("Job Title is displayed");
		} else {
			System.out.println("Job Title is not displayed");
		}
	}
/*******************************************************************************************
 * Method Name : public void validating_jobTitle()                                         *
 * Method Description : Add a jobtitle called "Automation Tester" if it is not             *
 * present in the list of jobtitles                                                        *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 2068108                                                                   * 
 *******************************************************************************************/
	public void collecting_jobTitle() {
		jobTitle.click();
		String lxpath = "/html/body/div[1]/div[3]/div[1]/div/div[2]/form/div[4]/table/tbody/tr[";
		String rxpath = "]/td[2]/a";
		for (int i = 1; i < 26; i++) {
			String xpath = lxpath + i + rxpath;
			String values = wd.findElement(By.xpath(xpath)).getText();
			titles.add(values);
		}
	}

	
}
