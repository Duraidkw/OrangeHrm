package orangehrm_mainprogram;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import com.google.common.io.Files;

public class OrangeHrm_Page2 {
	WebDriver wd;
	Properties p;
	FileReader fr;

	public void setDriver(WebDriver wd) {
		this.wd = wd;
	}

	public void setProperty(Properties p) {
		this.p = p;
	}
 /******************************************************************************************
 * Method Name : public void validate_dashboardurl()                                       *
 * Method Description : To validate the url of the currentpage and check whether it        *
 * contains the string "dashboard" or not.                                                 *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 2068108                                                                   *
 *******************************************************************************************/
	public void validate_dashboardurl() throws IOException {
		String c_url = wd.getCurrentUrl();
		if (c_url.contains(p.getProperty("dashboard_url"))) {
			System.out.println("url is correct");
		} else {
			System.out.println("Please,enter the correct url");
		}
		File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
		Files.copy(src, new File("./ScreenImages/orangehrmdashboard.png"));
	}
}
