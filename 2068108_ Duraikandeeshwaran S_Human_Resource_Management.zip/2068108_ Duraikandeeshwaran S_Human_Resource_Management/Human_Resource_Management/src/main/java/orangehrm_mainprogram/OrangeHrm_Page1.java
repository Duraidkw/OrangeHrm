package orangehrm_mainprogram;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.google.common.io.Files;

public class OrangeHrm_Page1 {
	WebDriver wd;
	Properties p = new Properties();
	String filepath = "./testdata/firstpage.properties";
	FileReader fr;
	WebElement job;
	WebElement jobTitle;
	List<String> titles = new ArrayList<String>();
/****************************************************************************************
 * Method Name : public WebDriver getDriver()                                           *                                               
 * Method Description : To getDriver path                                               *
 * Date of Creation : 06 December 2021                                                  *
 * Author : Duraikandeeshwaran S                                                        *
 * Employee Id : 2068108                                                                *
 ****************************************************************************************/
   public WebDriver getDriver() {
	   return wd;
   }
/*****************************************************************************************
 * Method Name : public Properties getProperty()                                         *
 * Method Description : To get the property                                              *
 * Date of Creation : 06 December 2021                                                   *
 * Author : Duraikandeeshwaran  S                                                        *
 * Employee Id : 2068108                                                                 *
 *****************************************************************************************/
   public Properties getProperty() {
   return p;
   }
	
/******************************************************************************************
 * Method Name : public void loadProperty()                                               *
 * Method Description : To load the the property file                                     *
 * Date of Creation : 06 December 2021                                                    *
 * Author : Duraikandeeshwaran S                                                          *
 * Employee Id : 2068108                                                                  *
 ******************************************************************************************/
public void loadProperty() {
	try {
		fr = new FileReader(filepath);
	} catch (FileNotFoundException e) {

		e.printStackTrace();
	}
	try {
		p.load(fr);
	} catch (IOException e) {
		e.printStackTrace();
	}
} 
/*******************************************************************************************
 * Method Name : public void settingpathFirefox()                                          *
 * Method Description : To setup the path for Firefox browser                              *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 20680108                                                                  *
 *******************************************************************************************/
	public void settingpathFirefox() {

		System.setProperty("webdriver.gecko.driver", "./driverfolder/geckodriver.exe");
		wd = new FirefoxDriver();
	}
/*******************************************************************************************
 * Method Name : public void settingpathChrome()                                           *
 * Method Description : To setup the path for Chrome browser                               *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 2068108                                                                   *
 *******************************************************************************************/	
	public void settingpathChrome() {
		System.setProperty("webdriver.chrome.driver", "./driverfolder/chromedriver.exe");
		wd = new ChromeDriver();
	}
/*******************************************************************************************
 * Method Name : public void maximize_browser()                                            *
 * Method Description : To maximize the browser and delete all cookies                     *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 2068108                                                                   *
 *******************************************************************************************/
	public void maximize_browser() {
	wd.manage().window().maximize();
	wd.manage().deleteAllCookies();
	}
/*******************************************************************************************
 * Method Name : public void invokeOrangeHRM()                                             *
 * Method Description : To invoke the OrangeHRM application in the browser                 *
 * Date of Creation : 06 December 2021                                                     *
 * Author :Duraikandeeshwaran S                                                            *
 * Employee Id : 2068108                                                                   *
 *******************************************************************************************/
	public void invokeOrangeHRM() throws IOException {
		wd.get(p.getProperty("url"));
	}
/*******************************************************************************************
 * Method Name : public void entering_username()                                           *
 * Method Description : To enter the value in the username textbox                         *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id :2068108                                                                    *
 *******************************************************************************************/
	public void entering_username() {
		WebElement user_name = wd.findElement(By.xpath("//input[@id='txtUsername']"));
		user_name.clear();
		user_name.sendKeys(p.getProperty("un"));

	}
/********************************************************************************************
 * Method Name : public void entering_password()                                            *
 * Method Description : To enter the value in the password textbox                          *
 * Date of Creation : 06 December 2021                                                      *
 * Author : Duraikandeeshwaran S                                                            *
 * Employee Id : 2068108                                                                    *                                            
 * @throws IOException                                                                      *
 ********************************************************************************************/
	public void entering_password() throws IOException {
		WebElement password = wd.findElement(By.xpath("//input[@id='txtPassword']"));
		password.clear();
		password.sendKeys(p.getProperty("pw"));
		File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
		Files.copy(src, new File("./ScreenImages/orangehrminvoke.png"));
	}
/********************************************************************************************
 * Method Name : public void clicking_loginbutton()                                         *
 * Method Description : To click on the login button                                        *
 * Date of Creation : 06 December 2021                                                      *
 * Author : Duraikandeeshwaran S                                                            *
 * Employee Id : 2068108                                                                    *
 ********************************************************************************************/

	public void clicking_loginbutton() {
		wd.findElement(By.xpath("//input[@id='btnLogin']")).click();
	}
}