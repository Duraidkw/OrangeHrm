package orangehrm_mainprogram;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
//import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.common.io.Files;

public class OrangeHrm_Page6 {

	WebDriver wd;
	Properties p;
	FileReader fr;
/******************************************************************************************
 * Method Name : public void setDriver(WebDriver wd)                                      *
 * Method Description : To setDriver path                                                 *
 * Date of Creation : 06 December 2021                                                    *
 * Author : Duraikandeeshwaran S                                                          *
 * Employee Id : 2068108                                                                  *
 ******************************************************************************************/
	public void setDriver(WebDriver wd) {
		this.wd = wd;
	}

	public void setProperty(Properties p) {
		this.p = p;
	}
/*******************************************************************************************
 * Method Name : public void log_out()                                                     *
 * Method Description : To logout from orangehrm page and close the browser                *
 * Date of Creation : 06 December 2021                                                     *
 * Author : Duraikandeeshwaran S                                                           *
 * Employee Id : 2068108                                                                   *
 * @throws InterruptedException                                                            *
 *******************************************************************************************/
	//@SuppressWarnings("deprecation")
	public void log_out() throws IOException, InterruptedException {
		wd.findElement(By.id("welcome")).click();
	WebElement rd=	wd.findElement(By.xpath("//a[text()='Logout']"));
	Thread.sleep(2000);
	    rd.click();
		//wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(2000);
		File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
		Files.copy(src, new File("./ScreenImages/loggingout.png"));
		wd.close();
	}


}