package orangehrm_mainprogram;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import com.google.common.io.Files;

public class OrangeHrm_Page5 {
	WebDriver wd;
	Properties p;
	FileReader fr;
	List<String> titles;

	public void setDriver(WebDriver wd) {
		this.wd = wd;
	}

	public void setProperty(Properties p) {
		this.p = p;
	}

	public void setTitles(List<String> titles) {
		this.titles = titles;
	}
/********************************************************************************************
 * Method Name : public void validating_jobTitle()                                          *
 * Method Description : Add a jobtitle called "Automation Tester" if it is not              *
 * present in the list of jobtitles                                                         *
 * Date of Creation : 06 December 2021                                                      *
 * Author : Duraikandeeshwaran S                                                            *
 * Employee Id : 2068108                                                                    
 * @throws InterruptedException *
 ********************************************************************************************/
	public void validating_jobTitle() throws IOException {
		String test = "Automation Tester";
		if (titles.contains(test)) {
			System.out.println("The given job is present in Job Titles");
		} else {
			wd.findElement(By.xpath(("//input[@id='btnAdd']"))).click();
			wd.findElement(By.xpath("//input[@id='jobTitle_jobTitle']")).sendKeys(p.getProperty("jobToAdd"));
			File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
			Files.copy(src, new File("./ScreenImages/addingjobtitle.png"));
			wd.findElement(By.id("btnSave")).click();
	
			File src1 = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
			Files.copy(src1, new File("./ScreenImages/addedjobtitle.png"));
			
		}
	}
}
