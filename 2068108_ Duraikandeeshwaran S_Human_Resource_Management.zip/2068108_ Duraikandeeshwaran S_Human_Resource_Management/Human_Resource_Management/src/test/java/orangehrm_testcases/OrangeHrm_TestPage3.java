package orangehrm_testcases;
import java.io.IOException;
import org.testng.annotations.Test;

public class OrangeHrm_TestPage3 extends OrangeHrm_TestPage2 {
	@Test(priority = 4, groups = "page3", dependsOnGroups = "page2")
	public void invokeAdminPageTest() throws IOException {
	obj3.navigatingTo_admin_tab();
	}
}

