package orangehrm_testcases;

import java.io.IOException;
import org.testng.annotations.Test;

public class OrangeHrm_TestPage4 extends OrangeHrm_TestPage3 {
	@Test(priority = 5, groups = "page4", dependsOnGroups = "page3")
	public void job_ValidationTest() {
		obj4.validating_job();
	}

	@Test(priority = 6, groups = "page4", dependsOnGroups = "page3")
	public void validationJobTitleTest() throws IOException {
		obj4.collecting_jobTitle();
		obj5.setTitles(obj4.getTitles());
	}

}