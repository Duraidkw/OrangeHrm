package orangehrm_testcases;

import java.io.IOException;

import org.testng.annotations.AfterTest;


public class OrangeHrm_TestPage6 extends OrangeHrm_TestPage5 {

	@AfterTest(groups = "page6", dependsOnGroups = "page5")
	public void logout_closetabTest() throws IOException, InterruptedException {
		obj6.log_out();
	}

}
