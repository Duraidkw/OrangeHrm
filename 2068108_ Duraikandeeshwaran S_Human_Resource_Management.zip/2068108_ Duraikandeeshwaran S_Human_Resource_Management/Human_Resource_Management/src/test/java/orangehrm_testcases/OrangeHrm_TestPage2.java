package orangehrm_testcases;

import java.io.IOException;

import org.testng.annotations.Test;

public class OrangeHrm_TestPage2 extends OrangeHrm_TestPage1 {
  @Test(priority = 3, groups = "page2", dependsOnGroups = "page1")
  public void validating_dashboardTest() throws IOException {
  obj2.validate_dashboardurl();
  }
}
