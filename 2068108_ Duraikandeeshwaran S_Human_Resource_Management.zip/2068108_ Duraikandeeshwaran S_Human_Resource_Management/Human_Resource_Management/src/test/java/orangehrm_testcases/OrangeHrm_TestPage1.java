package orangehrm_testcases;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import orangehrm_mainprogram.OrangeHrm_Page1;
import orangehrm_mainprogram.OrangeHrm_Page2;
import orangehrm_mainprogram.OrangeHrm_Page3;
import orangehrm_mainprogram.OrangeHrm_Page4;
import orangehrm_mainprogram.OrangeHrm_Page5;
import orangehrm_mainprogram.OrangeHrm_Page6;

public class OrangeHrm_TestPage1 {
	WebDriver wd;
	OrangeHrm_Page1 obj1;
	OrangeHrm_Page2 obj2;
	OrangeHrm_Page3 obj3;
	OrangeHrm_Page4 obj4;
	OrangeHrm_Page5 obj5;
	OrangeHrm_Page6 obj6;



	@Parameters("browsername_from_xml")
	@BeforeTest(groups = "page1")
	public void pre_condition(String browser) throws IOException {
	obj1 = new OrangeHrm_Page1();
	if (browser.equals("chrome")) {
	obj1.settingpathChrome();
	} else {
	obj1.settingpathFirefox();
	}
	obj1.maximize_browser();
	wd = obj1.getDriver();
	obj1.loadProperty();
	obj2 = new OrangeHrm_Page2();
	obj3 = new OrangeHrm_Page3();
	obj4 = new OrangeHrm_Page4();
	obj5 = new OrangeHrm_Page5();
	obj6 = new OrangeHrm_Page6();
	obj2.setDriver(obj1.getDriver());
	obj3.setDriver(obj1.getDriver());
	obj4.setDriver(obj1.getDriver());
	obj5.setDriver(obj1.getDriver());
	obj6.setDriver(obj1.getDriver());
	obj2.setProperty(obj1.getProperty());
	obj3.setProperty(obj1.getProperty());
	obj4.setProperty(obj1.getProperty());
	obj5.setProperty(obj1.getProperty());
	obj6.setProperty(obj1.getProperty());

	}



	@Test(priority = 1, groups = "page1")
	public void invokePage() throws IOException {
	obj1.invokeOrangeHRM();
	}



	@Test(priority = 2, groups = "page1")
	public void login_pageTest() throws IOException {
	obj1.entering_username();
	obj1.entering_password();
	obj1.clicking_loginbutton();



	}
}
