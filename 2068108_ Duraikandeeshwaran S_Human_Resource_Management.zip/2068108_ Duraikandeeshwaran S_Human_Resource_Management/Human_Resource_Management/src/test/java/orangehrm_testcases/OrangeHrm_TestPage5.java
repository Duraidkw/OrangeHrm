package orangehrm_testcases;

import java.io.IOException;

import org.testng.annotations.Test;

public class OrangeHrm_TestPage5 extends OrangeHrm_TestPage4 {
	@Test(priority = 7, groups = "page5", dependsOnGroups = "page4")
	public void TestvalidatingJobTitle() throws IOException {
	obj5.validating_jobTitle();
	}


	}

